﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Practica_Anghel
{
    public partial class Form8 : Form
    {
        public String conString = "Data Source=DESKTOP-A8SV8J6;Initial Catalog=Biblioteca; Integrated Security=True";
        public Form8()
        {
            InitializeComponent();
        }

        private void label11_Click(object sender, EventArgs e)
        {
            new Form3().Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string StrQuery;
            using (SqlConnection con = new SqlConnection(conString))
            {
               
                con.Open();

                string sqlStatement = "DELETE FROM limba_de_scriere";
                SqlCommand cmdd = new SqlCommand(sqlStatement, con);
                cmdd.CommandType = CommandType.Text;
                cmdd.ExecuteNonQuery();

                SqlDataAdapter sqlDa = new SqlDataAdapter("select * from Cărți where limba = '" + textBox1.Text + "' ", con);
                    DataTable dtbl = new DataTable();
                    sqlDa.Fill(dtbl);
                    dataGridView1.DataSource = dtbl;


                try
                {
                    SqlCommand cmd = new SqlCommand("insert into limba_de_scriere(Id, nume, autor, anul,nrExemplare,prețul,limba) select Id, nume, autor, anul,nrExemplare,prețul,limba from Cărți where limba = '" + textBox1.Text + "' ", con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("  bravo ");
                    con.Close();
                }
                catch (SystemException ex)
                {
                    MessageBox.Show(string.Format("nu nu", ex.Message));

                }

            }
        }



    }
}

