﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Practica_Anghel
{
    public partial class Form4 : Form
    {
        public String conString = "Data Source=DESKTOP-A8SV8J6;Initial Catalog=Biblioteca; Integrated Security=True";
        SqlDataAdapter adpt;
        DataTable dt;
        int Pw;
        bool hide;
        public Form4()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            new Form2().Show();
            this.Hide();
        }

        private void label11_Click(object sender, EventArgs e)
        {
            new Form3().Show();
            this.Hide();

        }

        private void button2_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(conString);
            con.Open();
            try
            {
                SqlCommand cmd = new SqlCommand("DELETE FROM Furnizori WHERE id = @ID", con);
                cmd.Parameters.AddWithValue("@ID", int.Parse(textBox1.Text));
                cmd.ExecuteNonQuery();
                MessageBox.Show("  bravo ");
                textBox1.Text = "";
                con.Close();
            }
            catch (SystemException ex)
            {
                MessageBox.Show(string.Format("nu nu", ex.Message));
               
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(conString);
            con.Open();
            try
            {
                SqlCommand cmd = new SqlCommand("DELETE FROM Furnizori WHERE Id =  @ID", con);
                cmd.Parameters.AddWithValue("@ID", 0);
                cmd.ExecuteNonQuery();
                MessageBox.Show(" bravo ");
                con.Close();
            }
            catch (SystemException ex)
            {
                MessageBox.Show(string.Format("tabelul furnizori nu contine inregistrari cu id 0", ex.Message));

            }
           
            con.Open();
            try
            {
                SqlCommand cmd = new SqlCommand("DELETE FROM Cărți WHERE Id = @ID", con);
                cmd.Parameters.AddWithValue("@ID", 0);
                cmd.ExecuteNonQuery();
               
                con.Close();
            }
            catch (SystemException ex)
            {
                MessageBox.Show(string.Format("tabelul Carti nu contine inregistrari cu id 0", ex.Message));

            }
        }
    }
}
