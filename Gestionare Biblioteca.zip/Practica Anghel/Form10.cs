﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Practica_Anghel
{
    public partial class Form10 : Form
    {
        public String conString = "Data Source=DESKTOP-A8SV8J6;Initial Catalog=Biblioteca; Integrated Security=True";
        public Form10()
        {
            InitializeComponent();
        }

        private void label11_Click(object sender, EventArgs e)
        {
            new Form3().Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            using (SqlConnection con = new SqlConnection(conString))
            {
                
                con.Open();
               

                string SqlString = "SELECT nume,nrExemplare FROM Cărți WHERE limba ='romana'";
                SqlDataAdapter sda = new SqlDataAdapter(SqlString, con);
                DataTable dt = new DataTable();
                try
                {
                    sda.Fill(dt);
                    dataGridView1.DataSource = dt;
                }
                catch (SqlException se)
                {
                    //  DBErLog.DbServLog(se, se.ToString());
                }
                finally
                {
                    con.Close();
                }

            }
        }
    }
}
