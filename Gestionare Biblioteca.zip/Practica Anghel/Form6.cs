﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Practica_Anghel
{
    public partial class Form6 : Form
    {
        public String conString = "Data Source=DESKTOP-A8SV8J6;Initial Catalog=Biblioteca; Integrated Security=True";
        public Form6()
        {
            InitializeComponent();
        }

        private void label11_Click(object sender, EventArgs e)
        {
            new Form3().Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int maxnum = 0;

            using (SqlConnection con = new SqlConnection(conString))
            {
                SqlCommand cmd = new SqlCommand("SELECT MAX(NrSurseLiterare) AS MaxOf FROM Furnizori", con);

                con.Open();
                maxnum = Convert.ToInt32(cmd.ExecuteScalar());

                string SqlString = "SELECT * FROM Furnizori WHERE NrSurseLiterare = '" + maxnum.ToString() + "'";
                SqlDataAdapter sda = new SqlDataAdapter(SqlString,con);
                DataTable dt = new DataTable();
                try
                {
                    sda.Fill(dt);
                    dataGridView1.DataSource = dt;
                }
                catch (SqlException se)
                {
                  //  DBErLog.DbServLog(se, se.ToString());
                }
                finally
                {
                    con.Close();
                }

            }
        }
    }
}
