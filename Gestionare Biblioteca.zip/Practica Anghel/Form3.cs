﻿using ClosedXML.Excel;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Practica_Anghel
{
    public partial class Form3 : Form
    {
        public String conString = "Data Source=DESKTOP-A8SV8J6;Initial Catalog=Biblioteca; Integrated Security=True";
        int PW;
        bool Hided;
        public Form3()
        {
            InitializeComponent();
            PW = panel2.Width;
            Hided = false;
        }

        private void label1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void flowLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {

        }

        private void FlowPanelMenu_Paint(object sender, PaintEventArgs e)
        {

        }

        private void FlowPanelMenu_Layout(object sender, LayoutEventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

            timer1.Start();

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (Hided)
            {
                panel2.Width = panel2.Width + 20;
                panel4.Width = panel4.Width - 20;
                if (panel2.Width >= PW)
                {
                    timer1.Stop();
                    Hided = false;
                    this.Refresh();
                }
            }
            else
            {
                panel2.Width = panel2.Width - 20;
                panel4.Width = panel4.Width + 20;
                if (panel2.Width <= 0)
                {
                    timer1.Stop();
                    Hided = true;
                    this.Refresh();
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            new Form2().Show();
            this.Hide();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            new Form2().Show();
            this.Hide();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            new Form2().Show();
            this.Hide();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            new Form2().Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            new Form4().Show();
            this.Hide();
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            new Form5().Show();
            this.Hide();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            new Form6().Show();
            this.Hide();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            new Form7().Show();
            this.Hide();
        }

        private void button11_Click(object sender, EventArgs e)
        {
            new Form8().Show();
            this.Hide();
        }

        private void button11_Click_1(object sender, EventArgs e)
        {
            new Form8().Show();
            this.Hide();
        }

        private void button10_Click(object sender, EventArgs e)
        {
            new Form9().Show();
            this.Hide();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            new Form10().Show();
            this.Hide();
        }
    }
}
    
