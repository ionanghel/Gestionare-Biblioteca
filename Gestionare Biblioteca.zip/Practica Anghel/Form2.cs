﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Practica_Anghel
{
    public partial class Form2 : Form
    {
        public String conString = "Data Source=DESKTOP-A8SV8J6;Initial Catalog=Biblioteca; Integrated Security=True";
        SqlDataAdapter adpt;
        DataTable dt;
        int Pw;
        bool hide;
        public Form2()
        {

            InitializeComponent();
          
            hide = false;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(conString);
            con.Open();

            if (con.State == System.Data.ConnectionState.Open)
            {
                try
                {
                    string q = "insert into Furnizori (Id,nume,localitatia,NrSurseLiterare) values('" + textBox1.Text.ToString() + "','" + textBox2.Text.ToString() + "', '" + textBox3.Text.ToString() + "','"+ textBox9.Text.ToString() + "')";
                    SqlCommand cmd = new SqlCommand(q, con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("  bravo ");
                }
                catch (Exception)
                {
                    MessageBox.Show("nu nu ");
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {

            SqlConnection con = new SqlConnection(conString);
            con.Open();

            if (con.State == System.Data.ConnectionState.Open)
            {
                try
                {
                    string q = "insert into Cărți (Id,nume,autor,anul,nrExemplare,prețul,limba) values('" + textBox6.Text.ToString() + "','" + textBox5.Text.ToString() + "', '" + textBox4.Text.ToString() + "', '" + textBox7.Text.ToString() + "', '" + textBox8.Text.ToString() +"', '" + textBox11.Text.ToString() + "', '" + textBox10.Text.ToString() + "')";
                    SqlCommand cmd = new SqlCommand(q, con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("  bravo ");
                }
                catch (Exception)
                {
                    MessageBox.Show("nu nu ");
                }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }


        private void Form2_Load(object sender, EventArgs e)
        {
          
        }
        private void pictureBox9_Click(object sender, EventArgs e)
        {
           
        }

        private void button6_Click(object sender, EventArgs e)
        {
            using (SqlConnection con = new SqlConnection(conString))
            {
                con.Open();
                SqlDataAdapter sqlDa = new SqlDataAdapter("select * from Cărți", con);
                DataTable dtbl = new DataTable();
                sqlDa.Fill(dtbl);
                dataGridView1.DataSource = dtbl;
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            using (SqlConnection con = new SqlConnection(conString))
            {
                con.Open();
                SqlDataAdapter sqlDa = new SqlDataAdapter("select * from Furnizori", con);
                DataTable dtbl = new DataTable();
                sqlDa.Fill(dtbl);
                dataGridView1.DataSource = dtbl;
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            using (SqlConnection con = new SqlConnection(conString))
            {
                con.Open();
                SqlDataAdapter sqlDa = new SqlDataAdapter("select * from Înregistrare", con);
                DataTable dtbl = new DataTable();
                sqlDa.Fill(dtbl);
                dataGridView1.DataSource = dtbl;
            }
        }

        private void label11_Click(object sender, EventArgs e)
        {
            new Form3().Show();
            this.Hide();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
