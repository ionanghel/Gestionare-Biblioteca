﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Practica_Anghel
{
    public partial class Form7 : Form
    {
        public String conString = "Data Source=DESKTOP-A8SV8J6;Initial Catalog=Biblioteca; Integrated Security=True";
        public Form7()
        {
            InitializeComponent();
        }

        private void label11_Click(object sender, EventArgs e)
        {
            new Form3().Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            using (SqlConnection con = new SqlConnection(conString))
            {
                con.Open();
                int d = 0;
                String f = "";
                String autput = "";
                String temp = "0";
                SqlDataReader reader;
                try
                {
                    string SqlString = "SELECT prețul FROM Cărți WHERE anul = '" + textBox1.Text + "'";
                    SqlCommand com = new SqlCommand(SqlString, con);
                    reader = com.ExecuteReader();
                    while (reader.Read())
                    {
                        autput = autput + reader.GetValue(0) + "+";
                    }
                    autput = autput + "0";

                    for (int i = 0; i < autput.Length; i++)
                    {
                        char ch = autput[i];

                        // if current character is a digit
                        if (char.IsDigit(ch))
                            temp += ch;

                        // if current character is an alphabet
                        else
                        {

                            // increment sum by number found earlier
                            // (if any)
                            d += int.Parse(temp);

                            // reset temporary string to empty
                            temp = "0";
                        }
                    }


                    MessageBox.Show(d.ToString());

                }
                catch (SqlException se)
                {
                    MessageBox.Show("nu nu");
                }
                finally
                {
                    con.Close();
                }


            }
        }
    }
}
