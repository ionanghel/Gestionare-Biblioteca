﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Practica_Anghel
{
    public partial class Biblioteca : Form
    {
       
        public String conString = "Data Source=DESKTOP-A8SV8J6;Initial Catalog=Biblioteca; Integrated Security=True";

        public Biblioteca()
        {
            InitializeComponent();
        }
        
        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (comboBox1.Text == "Elev")
            {
                MessageBox.Show(" Îmi pare rău dar nu ai acces ");
            }
            else if (comboBox1.Text != "Elev")
            {
                SqlConnection con = new SqlConnection(conString);
                con.Open();
                
                if (con.State == System.Data.ConnectionState.Open)
                {
                    try
                    {
                        string q = "insert into Înregistrare (Numele,Prenumele,Statutul) values('" + textBox1.Text.ToString() + "','" + textBox2.Text.ToString() + "', '" + comboBox1.Text.ToString() + "')";
                        SqlCommand cmd = new SqlCommand(q, con);
                        cmd.ExecuteNonQuery();
                      
                        new Form3().Show();
                        this.Hide();
                    }
                    catch (Exception)
                    {
                        MessageBox.Show("nu nu ");
                    }
                }
            }
        }
    }
}
